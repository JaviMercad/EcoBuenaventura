Instrucciones para usar el proyecto web localmente
1. Descomprime el archivo proyecto_web.zip.
2. Abre el archivo index.html en tu navegador (doble click).
3. Funcionalidades:
   - Ver mapa y simular camión en 'Rutas'.
   - Formulario 'Reporte Ciudadano' guarda reportes en localStorage (simula base de datos).
   - Proyecto: muestra justificación, objetivos, cronograma y presupuesto.
4. Para publicar en la web: subir los archivos a cualquier hosting estático (GitHub Pages, Netlify, Vercel).
