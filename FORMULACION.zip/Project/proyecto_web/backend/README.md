# Backend

Esta carpeta está reservada para la lógica del servidor, API y base de datos del proyecto.
Por el momento, el proyecto funciona como una aplicación estática servida desde la carpeta `frontend/`.
